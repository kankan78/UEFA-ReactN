export const players = [
  {
    id: '1',
    name: 'C. Ronaldo',
    match: 'BEL v POR',
    price: 12_200_000,
    position: 'FWD',
    totalPoints: 29
  },
  {
    id: '2',
    name: 'G. Wijnaldum',
    match: 'NED v CZE',
    price: 8_100_000,
    position: 'MID',
    totalPoints: 23
  },
  {
    id: '3',
    name: 'E. Forsberg',
    match: 'SWE v UKR',
    price: 7_700_000,
    position: 'MID',
    totalPoints: 23
  },
  {
    id: '4',
    name: 'D. Dumfries',
    match: 'NED v CZE',
    price: 5_600_000,
    position: 'DEF',
    totalPoints: 22
  },
  {
    id: '5',
    name: 'P. Schick',
    match: 'NED v CZE',
    price: 8_400_000,
    position: 'FWD',
    totalPoints: 21
  },
  {
    id: '6',
    name: 'X. Shaqiri',
    match: 'FRA v SUI',
    price: 7_200_000,
    position: 'MID',
    totalPoints: 21
  },
  {
    id: '7',
    name: 'M. Depay',
    match: 'NED v CZE',
    price: 10_100_000,
    position: 'FWD',
    totalPoints: 20
  },
  {
    id: '8',
    name: 'C. Ronaldo',
    match: 'BEL v POR',
    price: 12_200_000,
    position: 'FWD',
    totalPoints: 29
  },
  {
    id: '9',
    name: 'G. Wijnaldum',
    match: 'NED v CZE',
    price: 8_100_000,
    position: 'MID',
    totalPoints: 23
  },
  {
    id: '10',
    name: 'E. Forsberg',
    match: 'SWE v UKR',
    price: 7_700_000,
    position: 'MID',
    totalPoints: 23
  },
  {
    id: '11',
    name: 'D. Dumfries',
    match: 'NED v CZE',
    price: 5_600_000,
    position: 'DEF',
    totalPoints: 22
  },
  {
    id: '12',
    name: 'P. Schick',
    match: 'NED v CZE',
    price: 8_400_000,
    position: 'FWD',
    totalPoints: 21
  },
  {
    id: '13',
    name: 'X. Shaqiri',
    match: 'FRA v SUI',
    price: 7_200_000,
    position: 'MID',
    totalPoints: 21
  },
  {
    id: '14',
    name: 'M. Depay',
    match: 'NED v CZE',
    price: 10_100_000,
    position: 'FWD',
    totalPoints: 20
  },
]